package Q13_3;

interface Person {  // 人インターフェース
    void introduce();
}
