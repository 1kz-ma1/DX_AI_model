public class MoreCalc extends Calculator { // MoreCalcクラス
    public int CalcPow(int a, int b){  // べき乗計算
        return (int) Math.pow(a, b);
    }
}
