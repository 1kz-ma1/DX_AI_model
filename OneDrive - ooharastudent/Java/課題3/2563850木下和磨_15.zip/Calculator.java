public class Calculator {  // 計算機クラス
    public int CalcSum(int a, int b) {// 2つの整数の和
        return a + b;
    }

    public int CalcAve(int a, int b) {// 2つの整数の平均
        return (a + b) / 2;
    }
}
